# PBX-36 Modular Ultra — Complete Fabrication Package (MIT open hardware)

## Contents
- `pbx36-chassis.stl` — rugged enclosure 200x140x80mm, 3mm walls, WAGO rails,
  10S battery bay, ventilation louvers. Every solid manifold-verified.
- `pbx36-front-panel.stl` — faceplate with exact cutouts: 2x 16mm pushbuttons,
  45x26mm voltmeter bezel, 32x15mm USB cutout, 16x10mm XT60 slot, 40mm 220V
  socket, 4x M3 mounting holes.
- `pbx36-wiring-guide.pdf` — A4 vector wiring blueprint (power chain, TL431
  divider, gate drive) + connection table + threshold math + safety checklist.
- `BOM.csv` — full bill of materials with Tunisian sourcing hints.

## Print settings (recommended)
- Material: PETG | Layer 0.2mm | Infill 30% gyroid | Walls: 4 | Top/bottom: 5
- Chassis prints open-side up, no supports (louvers are self-supporting at 35°).
- Faceplate prints flat, face down. Mount with 4x M3x12 + heat-set inserts.

## Electrical safety (read PDF first)
1. 15A blade fuse FIRST after battery+. Never bypass BMS or fuse.
2. Pre-set MPPT output to 42.0V before connecting the pack.
3. Calibrate RV1 for 31.00V cut-off; verify 0.00mA standby on mA range.
4. AWG 14 silicone for battery/solar; AWG 20 for logic/driver.

## Regenerate from source
`python3 scripts/generate_models.py && python3 scripts/generate_wiring_pdf.py   && python3 scripts/bundle_package.py`

Project home: https://github.com/HiTechTN/wattouna-platform
Live portal: https://wattouna.pages.dev
